App utilisation

First the list of usefull libraries is saved in the file requirements.txt.
To download these libraries, you should write :
-> pip install -r requirements.txt

To launch the app :
-> python ./main.py

Then the app will ask you which photo you want to process. You have to write the path to the photo.
For example :
-> tests/112.JPG
Some photos are saved in the folder tests in order to try the program.

Normally a photo will open with the 4 angulars of the tray colored in red.
The terminal will ask you if you want keep them or change them manually.

To keep them you have to press y and enter.
To change them press n + enter.

If you pressed 'n', a new image will open and you have to click on the 4 angulars, then close the image with the top right cross.

Next, the program will search for the blocks on the tray, the results are saved in the folder 'results'.

Now you can continue by doing the same.

If you want to exit the app, write :
-> quit

If you want to print the help, write the following line :
-> ?